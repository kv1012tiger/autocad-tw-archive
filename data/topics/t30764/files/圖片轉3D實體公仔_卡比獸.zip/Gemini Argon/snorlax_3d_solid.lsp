;; ============================================================================
;; 檔案名稱: snorlax_3d_solid.lsp
;; 模型名稱: 寶可夢 卡比獸 (Snorlax) 1:1 精細三視圖還原 3D 實體模型 (Height = 2240 mm)
;; 建模核心: AutoCAD ACIS 3DSOLID (NURBS 多斷面 _LOFT + CSG _INTERSECT / _SUBTRACT / _UNION)
;; 單位系統: 公釐 (mm) — 總高 Z = 0.0 ~ 2240.0 mm, 肩手總寬 X = -1205 ~ +1205 mm
;; 執行指令: APPLOAD 載入後，於指令列輸入 SNORLAX3D 即可自動生成完整 3D 實體模型
;; ============================================================================
;; 【精細特徵一覽】
;; 1. 軀幹與頭部主體 (SNORLAX-BODY-TEAL)  : 依據正/側/背三視圖像素比例量測之 21 層非對稱中心 NURBS 橢圓斷面混成實體
;; 2. 雙耳立體造型   (SNORLAX-BODY-TEAL)  : 3D 傾斜軸向 7 斷面混成貓耳實體 + 前側耳窩布林差集 (_SUBTRACT) 內凹雕刻
;; 3. 貼合式米白肚皮 (SNORLAX-BELLY-CREAM): 以軀幹外擴曲面與正視圖肚皮輪廓進行 3D 布林交集 (_INTERSECT)，100% 貼合肚皮曲率
;; 4. M字額頭米白臉部(SNORLAX-FACE-CREAM) : 以頭部外擴曲面布林交集生成貼合臉部實體，並以 3D 楔形刀模差集 (_SUBTRACT) 雕刻出額頭中央美人尖 (M字山峰)
;; 5. 雙臂與手掌實體 (SNORLAX-BODY-TEAL)  : 沿 3D 空間弧線配置的 9 斷面法向混成實體，呈現厚實肩膀至圓潤手掌的漸變
;; 6. 手部十爪實體   (SNORLAX-CLAWS-WHITE): 左右手各 5 支沿手掌下緣弧線排列之 5 斷面彎曲圓錐實體爪 (共 10 爪)
;; 7. 豐滿雙腳腳掌   (SNORLAX-FEET-CREAM) : 左右外八 16 度配置之 8 斷面立體腳掌實體 + 底部橢圓肉球 (SNORLAX-PAWPAD-TAN)
;; 8. 腳部六爪實體   (SNORLAX-CLAWS-WHITE): 左右腳前緣各 3 支大型微彎曲立體圓錐腳爪 (共 6 爪)
;; 9. 立體五官與獠牙 (SNORLAX-FACE-DARK / SNORLAX-CLAWS-WHITE):
;;    - 貼合臉部 3D 曲面的微彎瞇瞇眼立體圓管實體
;;    - 貼合臉部曲面的嘴線立體圓管實體
;;    - 嘴角兩側向上突出的立體三角錐下犬齒 (獠牙) 實體與深色牙齦基座
;; ============================================================================

(vl-load-com)

;; ----------------------------------------------------------------------------
;; 1. 向量與幾何輔助函數 (3D Vector & Geometry Math Utilities)
;; ----------------------------------------------------------------------------

(defun snx:v-add (a b) (mapcar '+ a b))
(defun snx:v-sub (a b) (mapcar '- a b))
(defun snx:v-scale (v s) (mapcar '(lambda (x) (* x (float s))) v))
(defun snx:v-dot (a b) (apply '+ (mapcar '* a b)))

(defun snx:v-cross (a b)
  (list
    (- (* (nth 1 a) (nth 2 b)) (* (nth 2 a) (nth 1 b)))
    (- (* (nth 2 a) (nth 0 b)) (* (nth 0 a) (nth 2 b)))
    (- (* (nth 0 a) (nth 1 b)) (* (nth 1 a) (nth 0 b)))
  )
)

(defun snx:v-len (v)
  (sqrt (apply '+ (mapcar '(lambda (x) (* (float x) (float x))) v)))
)

(defun snx:v-unit (v / l)
  (setq l (snx:v-len v))
  (if (> l 1e-8)
    (snx:v-scale v (/ 1.0 l))
    '(0.0 0.0 1.0)
  )
)

;; 建立與法向量 N 正交的局部座標基底 (U, V, N)
;; ref-u 為優先參考方向向量，確保各斷面軸向一致不發生 _LOFT 扭轉 (Twist)
(defun snx:make-frame (n ref-u / n-unit u-proj u-unit v-unit)
  (setq n-unit (snx:v-unit n))
  (setq u-proj (snx:v-sub ref-u (snx:v-scale n-unit (snx:v-dot ref-u n-unit))))
  (if (< (snx:v-len u-proj) 1e-5)
    (setq u-proj (snx:v-sub '(1.0 0.0 0.0) (snx:v-scale n-unit (nth 0 n-unit))))
  )
  (if (< (snx:v-len u-proj) 1e-5)
    (setq u-proj (snx:v-sub '(0.0 1.0 0.0) (snx:v-scale n-unit (nth 1 n-unit))))
  )
  (setq u-unit (snx:v-unit u-proj))
  (setq v-unit (snx:v-unit (snx:v-cross n-unit u-unit)))
  (list u-unit v-unit n-unit)
)

;; ----------------------------------------------------------------------------
;; 2. 圖層與 TrueColor 色彩系統初始化 (Layer & TrueColor Setup)
;; ----------------------------------------------------------------------------

(defun snx:create-layer (lay-name aci-color rgb-list / acad-doc layers lay-obj acm-col)
  (if (not (tblsearch "LAYER" lay-name))
    (entmake
      (list
        '(0 . "LAYER")
        '(100 . "AcDbSymbolTableRecord")
        '(100 . "AcDbLayerTableRecord")
        (cons 2 lay-name)
        '(70 . 0)
        (cons 62 aci-color)
        '(6 . "Continuous")
      )
    )
  )
  ;; 設定 TrueColor (RGB)，讓 Conceptual / Realistic / Shaded 模式呈現精確寶可夢配色
  (if rgb-list
    (vl-catch-all-apply
      '(lambda ()
         (setq acad-doc (vla-get-ActiveDocument (vlax-get-acad-object)))
         (setq layers (vla-get-Layers acad-doc))
         (setq lay-obj (vla-Item layers lay-name))
         (setq acm-col (vla-get-TrueColor lay-obj))
         (vla-put-ColorMethod acm-col acColorMethodByRGB)
         (vla-SetRGB acm-col (nth 0 rgb-list) (nth 1 rgb-list) (nth 2 rgb-list))
         (vla-put-TrueColor lay-obj acm-col)
       )
    )
  )
)

(defun snx:init-layers ()
  ;; 1. 身體與頭部深藍綠色 (Pokémon GO 卡比獸標準藍綠 R=18, G=122, B=150)
  (snx:create-layer "SNORLAX-BODY-TEAL"   134 '(18 122 150))
  ;; 2. 肚皮與臉部溫暖米白色 (R=242, G=240, B=230)
  (snx:create-layer "SNORLAX-BELLY-CREAM" 254 '(242 240 230))
  (snx:create-layer "SNORLAX-FACE-CREAM"  254 '(244 242 234))
  ;; 3. 雙腳米白色 (R=238, G=235, B=224)
  (snx:create-layer "SNORLAX-FEET-CREAM"  254 '(238 235 224))
  ;; 4. 腳底肉球淺棕粉色 (R=176, G=140, B=118)
  (snx:create-layer "SNORLAX-PAWPAD-TAN"   32 '(176 140 118))
  ;; 5. 手爪、腳爪與獠牙純白色 (R=250, G=250, B=248)
  (snx:create-layer "SNORLAX-CLAWS-WHITE" 255 '(250 250 248))
  ;; 6. 閉眼、嘴線與耳窩深灰黑色 (R=38, G=42, B=46)
  (snx:create-layer "SNORLAX-FACE-DARK"   250 '(38 42 46))
  ;; 7. 展示底座圓盤 (選配展示層)
  (snx:create-layer "SNORLAX-BASE-RING"   141 '(85 175 195))
)

;; ----------------------------------------------------------------------------
;; 3. 核心 NURBS 橢圓斷面與 _LOFT 3DSOLID 建構引擎
;; ----------------------------------------------------------------------------

;; 於 WCS 水平面 (Normal = 0,0,1) 建立精確 DXF ELLIPSE 實體
;; 自動判斷長短軸以確保 DXF (40 . ratio) 恆介於 0.001 ~ 1.0，絕不發生 entmake 失敗
(defun snx:make-horiz-ellipse (cx cy cz rx ry lay / maj-vec ratio)
  (setq rx (max 0.5 (float rx)))
  (setq ry (max 0.5 (float ry)))
  (if (>= rx ry)
    (progn
      (setq maj-vec (list rx 0.0 0.0))
      (setq ratio (/ ry rx))
    )
    (progn
      (setq maj-vec (list 0.0 ry 0.0))
      (setq ratio (/ rx ry))
    )
  )
  (setq ratio (max 0.001 (min 1.0 ratio)))
  (entmakex
    (list
      '(0 . "ELLIPSE")
      '(100 . "AcDbEntity")
      (cons 8 lay)
      '(100 . "AcDbEllipse")
      (list 10 (float cx) (float cy) (float cz))
      (cons 11 maj-vec)
      '(210 0.0 0.0 1.0)
      (cons 40 ratio)
      '(41 . 0.0)
      (cons 42 (* 2.0 pi))
    )
  )
)

;; 於任意 3D 空間平面 (中心 pt, 法向 normal, 局部軸 ref-u, 半徑 ru, rv) 建立 DXF ELLIPSE
(defun snx:make-oriented-ellipse (pt normal ref-u ru rv lay / frame u-vec v-vec n-vec maj-vec ratio)
  (setq ru (max 0.5 (float ru)))
  (setq rv (max 0.5 (float rv)))
  (setq frame (snx:make-frame normal ref-u))
  (setq u-vec (nth 0 frame))
  (setq v-vec (nth 1 frame))
  (setq n-vec (nth 2 frame))
  (if (>= ru rv)
    (progn
      (setq maj-vec (snx:v-scale u-vec ru))
      (setq ratio (/ rv ru))
    )
    (progn
      (setq maj-vec (snx:v-scale v-vec rv))
      (setq ratio (/ ru rv))
    )
  )
  (setq ratio (max 0.001 (min 1.0 ratio)))
  (entmakex
    (list
      '(0 . "ELLIPSE")
      '(100 . "AcDbEntity")
      (cons 8 lay)
      '(100 . "AcDbEllipse")
      (cons 10 (mapcar 'float pt))
      (cons 11 (mapcar 'float maj-vec))
      (cons 210 (mapcar 'float n-vec))
      (cons 40 ratio)
      '(41 . 0.0)
      (cons 42 (* 2.0 pi))
    )
  )
)

;; 沿一系列水平橢圓斷面規格 ((cx cy cz rx ry) ...) 執行 _LOFT 混成 3DSOLID
;; 採用 CMDACTIVE 迴圈自動收尾，相容所有 AutoCAD 版本與語系，並自動清除暫存剖面線
(defun snx:loft-horiz-sections (sec-list lay / profs e last-before new-ent)
  (setvar "CLAYER" lay)
  (setq profs nil)
  (foreach s sec-list
    (setq e (snx:make-horiz-ellipse (nth 0 s) (nth 1 s) (nth 2 s) (nth 3 s) (nth 4 s) lay))
    (if e (setq profs (append profs (list e))))
  )
  (if (>= (length profs) 2)
    (progn
      (setq last-before (entlast))
      (command "_LOFT")
      (foreach p profs (command p))
      (while (> (getvar "CMDACTIVE") 0)
        (command "")
      )
      (setq new-ent (entlast))
      ;; 清理未被 DELOBJ 自動刪除的暫存斷面
      (foreach p profs
        (if (and p (entget p) (not (eq p new-ent)))
          (entdel p)
        )
      )
      (if (not (eq new-ent last-before)) new-ent nil)
    )
    nil
  )
)

;; 沿 3D 空間導引路徑 ((pt normal ref-u ru rv) ...) 執行 _LOFT 混成 3DSOLID
(defun snx:loft-oriented-sections (sec-list lay / profs e last-before new-ent)
  (setvar "CLAYER" lay)
  (setq profs nil)
  (foreach s sec-list
    (setq e (snx:make-oriented-ellipse (nth 0 s) (nth 1 s) (nth 2 s) (nth 3 s) (nth 4 s) lay))
    (if e (setq profs (append profs (list e))))
  )
  (if (>= (length profs) 2)
    (progn
      (setq last-before (entlast))
      (command "_LOFT")
      (foreach p profs (command p))
      (while (> (getvar "CMDACTIVE") 0)
        (command "")
      )
      (setq new-ent (entlast))
      (foreach p profs
        (if (and p (entget p) (not (eq p new-ent)))
          (entdel p)
        )
      )
      (if (not (eq new-ent last-before)) new-ent nil)
    )
    nil
  )
)

;; 沿 3D 點列 ((pt radius) ...) 自動計算切線方向並混成平滑圓管/錐體 3DSOLID
(defun snx:loft-tube-along-pts (pt-rad-list ref-u lay / n-pts i p-prev p-curr p-next tang r sec-list)
  (setq n-pts (length pt-rad-list))
  (setq sec-list nil)
  (setq i 0)
  (while (< i n-pts)
    (setq p-curr (nth 0 (nth i pt-rad-list)))
    (setq r      (nth 1 (nth i pt-rad-list)))
    (cond
      ((= i 0)
       (setq p-next (nth 0 (nth (1+ i) pt-rad-list)))
       (setq tang (snx:v-unit (snx:v-sub p-next p-curr)))
      )
      ((= i (1- n-pts))
       (setq p-prev (nth 0 (nth (1- i) pt-rad-list)))
       (setq tang (snx:v-unit (snx:v-sub p-curr p-prev)))
      )
      (T
       (setq p-prev (nth 0 (nth (1- i) pt-rad-list)))
       (setq p-next (nth 0 (nth (1+ i) pt-rad-list)))
       (setq tang (snx:v-unit (snx:v-sub p-next p-prev)))
      )
    )
    (setq sec-list (append sec-list (list (list p-curr tang ref-u r r))))
    (setq i (1+ i))
  )
  (snx:loft-oriented-sections sec-list lay)
)

;; 安全布林聯集 (_UNION)
(defun snx:boolean-union (ent-list / valid-list)
  (setq valid-list nil)
  (foreach e ent-list
    (if (and e (entget e))
      (setq valid-list (append valid-list (list e)))
    )
  )
  (if (>= (length valid-list) 2)
    (progn
      (command "_UNION")
      (foreach e valid-list (command e))
      (while (> (getvar "CMDACTIVE") 0) (command ""))
      (entlast)
    )
    (car valid-list)
  )
)

;; 安全布林交集 (_INTERSECT)
(defun snx:boolean-intersect (e1 e2)
  (if (and e1 e2 (entget e1) (entget e2))
    (progn
      (command "_INTERSECT" e1 e2)
      (while (> (getvar "CMDACTIVE") 0) (command ""))
      (entlast)
    )
    nil
  )
)

;; 安全布林差集 (_SUBTRACT)
(defun snx:boolean-subtract (base-ent sub-list / valid-subs)
  (setq valid-subs nil)
  (foreach e sub-list
    (if (and e (entget e))
      (setq valid-subs (append valid-subs (list e)))
    )
  )
  (if (and base-ent (entget base-ent) valid-subs)
    (progn
      (command "_SUBTRACT" base-ent "")
      (foreach e valid-subs (command e))
      (while (> (getvar "CMDACTIVE") 0) (command ""))
      base-ent
    )
    base-ent
  )
)

;; ----------------------------------------------------------------------------
;; 4. 卡比獸各部位 1:1 精細三視圖量測數據與實體建模模組
;; ----------------------------------------------------------------------------

;; 【模組 A】建立軀幹水平斷面表 (依三視圖 00110/00210/00310 像素量測轉換 1:1 mm)
;; dr 為徑向偏移量 (mm)：dr = 0.0 用於藍綠主軀幹；dr = +14.0 用於肚皮貼合層交集母體
(defun snx:get-torso-sections (dr)
  (mapcar
    '(lambda (row)
       (list
         (nth 0 row)
         (nth 1 row)
         (nth 2 row)
         (+ (nth 3 row) dr)
         (+ (nth 4 row) dr)
       )
     )
    '(
      ;; (cx    cy       cz      rx      ry)
      (0.0   -22.0    115.0   240.0   190.0)  ; 骨盆底端收口
      (0.0   -38.0    165.0   485.0   385.0)  ; 臀部下緣
      (0.0   -55.0    245.0   695.0   555.0)  ; 下腹底部
      (0.0   -68.0    365.0   828.0   675.0)  ; 下腹擴張段
      (0.0   -78.0    515.0   895.0   742.0)  ; 中下腹最寬前突區
      (0.0   -82.0    675.0   918.0   772.0)  ; 肚臍最大腹圍處 (總寬 1836mm, 總深 1544mm)
      (0.0   -79.0    845.0   905.0   760.0)  ; 中上腹飽滿區
      (0.0   -72.0   1015.0   852.0   718.0)  ; 胸腹交界
      (0.0   -60.0   1185.0   762.0   642.0)  ; 胸腔中段
      (0.0   -48.0   1335.0   645.0   545.0)  ; 肩部上胸段
      (0.0   -38.0   1455.0   515.0   448.0)  ; 頸部交界處
      (0.0   -35.0   1545.0   395.0   350.0)  ; 伸入頭部內部接合段
    )
  )
)

;; 【模組 B】建立頭部水平斷面表 (Z = 1425 ~ 2090 mm)
;; dr = 0.0 用於藍綠頭部主體；dr = +12.0 用於米白臉部面具交集母體
(defun snx:get-head-sections (dr)
  (mapcar
    '(lambda (row)
       (list
         (nth 0 row)
         (nth 1 row)
         (nth 2 row)
         (+ (nth 3 row) dr)
         (+ (nth 4 row) dr)
       )
     )
    '(
      ;; (cx    cy       cz      rx      ry)
      (0.0   -48.0   1425.0   380.0   340.0)  ; 頸部底端嵌入式基座
      (0.0   -68.0   1495.0   462.0   405.0)  ; 下顎底部
      (0.0   -86.0   1585.0   498.0   440.0)  ; 臉頰下緣豐滿區
      (0.0   -96.0   1695.0   512.0   458.0)  ; 臉頰最大寬度區 (總寬 1024mm)
      (0.0   -95.0   1805.0   504.0   450.0)  ; 顴骨與眼下區
      (0.0   -88.0   1905.0   482.0   425.0)  ; 額頭與雙眼高度
      (0.0   -76.0   1990.0   435.0   372.0)  ; 上額頭與耳根區
      (0.0   -64.0   2050.0   345.0   290.0)  ; 頭頂弧面過渡
      (0.0   -56.0   2088.0   185.0   155.0)  ; 頭頂圓拱頂端
    )
  )
)

;; 【模組 C】建立左右立體尖耳 (含耳窩內凹差集雕刻)
(defun snx:build-ear (side / s axis ref-u ear-secs ear-solid hollow-secs hollow-solid)
  (setq s (float side)) ; -1.0 = 左耳, +1.0 = 右耳
  ;; 耳朵由頭側向上、向外、微向前延伸至 Z = 2240 mm 最高點
  (setq axis (snx:v-unit (list (* s 0.34) 0.08 0.937)))
  (setq ref-u (list s 0.0 0.0))
  (setq ear-secs
    (list
      (list (list (* s 275.0) -65.0 1920.0) axis ref-u 148.0 118.0)
      (list (list (* s 305.0) -58.0 1995.0) axis ref-u 138.0 106.0)
      (list (list (* s 332.0) -51.0 2070.0) axis ref-u 116.0  88.0)
      (list (list (* s 356.0) -45.0 2140.0) axis ref-u  86.0  64.0)
      (list (list (* s 375.0) -40.0 2198.0) axis ref-u  50.0  38.0)
      (list (list (* s 388.0) -36.0 2232.0) axis ref-u  22.0  17.0)
      (list (list (* s 392.0) -35.0 2240.0) axis ref-u   8.0   6.0)
    )
  )
  (setq ear-solid (snx:loft-oriented-sections ear-secs "SNORLAX-BODY-TEAL"))
  ;; 建立前側淺耳窩凹槽切割體，使耳朵正面呈現自然微凹立體感
  (setq hollow-secs
    (list
      (list (list (* s 315.0) -148.0 2010.0) axis ref-u 58.0 42.0)
      (list (list (* s 338.0) -132.0 2080.0) axis ref-u 52.0 38.0)
      (list (list (* s 358.0) -112.0 2148.0) axis ref-u 36.0 28.0)
      (list (list (* s 372.0)  -95.0 2195.0) axis ref-u 15.0 12.0)
    )
  )
  (setq hollow-solid (snx:loft-oriented-sections hollow-secs "SNORLAX-BODY-TEAL"))
  (if (and ear-solid hollow-solid)
    (snx:boolean-subtract ear-solid (list hollow-solid))
  )
  ear-solid
)

;; 【模組 D】建立貼合式米白肚皮 3DSOLID (CSG 布林交集法)
;; 原理:
;;   1. 建立外擴 +14mm 的軀幹母體 (outer-torso) 與內縮 -25mm 的軀幹內核 (inner-torso)
;;   2. 建立正視圖米白肚皮輪廓的 3D 錐台切割體 (belly-mask)，完全依據 00110.jpg 肚皮寬度曲線
;;   3. 以 (outer-torso INTERSECT belly-mask) 減去 inner-torso，獲得厚度 39mm、100% 貼合軀幹曲率的立體米白肚皮實體！
(defun snx:build-belly-patch (/ outer-torso inner-torso mask-secs belly-mask belly-solid)
  (setq outer-torso (snx:loft-horiz-sections (snx:get-torso-sections 14.0) "SNORLAX-BELLY-CREAM"))
  (setq inner-torso (snx:loft-horiz-sections (snx:get-torso-sections -25.0) "SNORLAX-BELLY-CREAM"))
  ;; 正視圖米白肚皮各高度 (Z = 250 ~ 1425 mm) 的精確左右半寬 rx，並涵蓋前側深度 (cy = -520, ry = 460)
  (setq mask-secs
    '(
      ;; (cx    cy       cz      rx      ry)
      (0.0  -520.0    255.0   220.0   460.0)  ; 肚皮底端圓弧下緣
      (0.0  -520.0    310.0   385.0   460.0)
      (0.0  -520.0    405.0   535.0   460.0)
      (0.0  -520.0    535.0   638.0   460.0)
      (0.0  -520.0    685.0   692.0   460.0)  ; 肚皮最寬處 (總寬 1384mm)
      (0.0  -520.0    845.0   685.0   460.0)
      (0.0  -520.0   1005.0   635.0   460.0)
      (0.0  -520.0   1155.0   552.0   460.0)
      (0.0  -520.0   1285.0   438.0   460.0)
      (0.0  -520.0   1375.0   295.0   460.0)
      (0.0  -520.0   1422.0   135.0   460.0)  ; 肚皮頂端胸口圓拱
    )
  )
  (setq belly-mask (snx:loft-horiz-sections mask-secs "SNORLAX-BELLY-CREAM"))
  (setq belly-solid (snx:boolean-intersect outer-torso belly-mask))
  (if (and belly-solid inner-torso)
    (snx:boolean-subtract belly-solid (list inner-torso))
  )
  belly-solid
)

;; 【模組 E】建立貼合式米白臉部面具 + 額頭 M 字美人尖雕刻 (CSG _INTERSECT + _SUBTRACT)
(defun snx:build-face-mask (/ outer-head inner-head face-mask-secs face-mask face-solid v-notch-secs v-notch-cutter)
  (setq outer-head (snx:loft-horiz-sections (snx:get-head-sections 12.0) "SNORLAX-FACE-CREAM"))
  (setq inner-head (snx:loft-horiz-sections (snx:get-head-sections -22.0) "SNORLAX-FACE-CREAM"))
  ;; 正視圖 (00110.jpg) 米白臉部輪廓半寬 rx (Z = 1500 ~ 2025 mm)
  (setq face-mask-secs
    '(
      ;; (cx    cy       cz      rx      ry)
      (0.0  -360.0   1505.0   175.0   320.0)  ; 下巴底端圓弧
      (0.0  -360.0   1560.0   295.0   320.0)
      (0.0  -360.0   1640.0   385.0   320.0)
      (0.0  -360.0   1735.0   426.0   320.0)  ; 臉頰米白區最寬處
      (0.0  -360.0   1835.0   412.0   320.0)
      (0.0  -360.0   1925.0   368.0   320.0)
      (0.0  -360.0   1990.0   292.0   320.0)
      (0.0  -360.0   2028.0   195.0   320.0)  ; 額頭頂緣
    )
  )
  (setq face-mask (snx:loft-horiz-sections face-mask-secs "SNORLAX-FACE-CREAM"))
  (setq face-solid (snx:boolean-intersect outer-head face-mask))
  (if (and face-solid inner-head)
    (snx:boolean-subtract face-solid (list inner-head))
  )
  ;; 建立額頭中央 M 字形美人尖 (Widow's Peak) 3D 倒錐切割體 (Z = 1912 ~ 2060 mm, X = 0)
  ;; 雕刻出正視圖額頭中央深藍綠毛色向下延伸的經典山峰缺口
  (setq v-notch-secs
    '(
      ;; (cx    cy       cz      rx      ry)
      (0.0  -435.0   1912.0     6.0   180.0)  ; 美人尖最低點尖端 (Z=1912mm)
      (0.0  -435.0   1945.0    38.0   180.0)
      (0.0  -435.0   1985.0    88.0   180.0)
      (0.0  -435.0   2025.0   148.0   180.0)
      (0.0  -435.0   2060.0   195.0   180.0)
    )
  )
  (setq v-notch-cutter (snx:loft-horiz-sections v-notch-secs "SNORLAX-FACE-CREAM"))
  (if (and face-solid v-notch-cutter)
    (snx:boolean-subtract face-solid (list v-notch-cutter))
  )
  face-solid
)

;; 【模組 F】建立左右立體手臂與手掌 (9 斷面 3D 空間曲線導引混成 + 10 支彎曲手爪)
(defun snx:build-arm-and-claws (side / s ref-u arm-pts n-pts i p-curr p-prev p-next tang ru rv arm-secs arm-solid
                                      claw-offsets idx dy cx0 cy0 cz0 claw-pts)
  (setq s (float side)) ; -1.0 = 左手, +1.0 = 右手
  (setq ref-u '(0.0 1.0 0.0)) ; 以 Y 軸 (前後方向) 作為手掌寬度主軸，使手掌呈自然扁橢圓槳狀
  ;; 手臂 3D 中心線與橫斷面半軸 (ru = 前後寬度半徑, rv = 厚薄半徑)
  (setq arm-pts
    (list
      ;; ((x         y       z)       ru      rv)
      (list (list (* s  455.0) -42.0 1365.0) 215.0 165.0) ; 嵌入肩部根部
      (list (list (* s  585.0) -56.0 1305.0) 232.0 172.0) ; 上臂肩關節
      (list (list (* s  725.0) -68.0 1215.0) 242.0 168.0) ; 上臂中段飽滿區
      (list (list (* s  865.0) -78.0 1105.0) 238.0 156.0) ; 手肘過渡區
      (list (list (* s  988.0) -86.0  990.0) 222.0 138.0) ; 前臂中段
      (list (list (* s 1088.0) -92.0  885.0) 195.0 116.0) ; 手腕至手掌
      (list (list (* s 1155.0) -96.0  805.0) 152.0  86.0) ; 手掌下緣
      (list (list (* s 1192.0) -98.0  755.0)  95.0  52.0) ; 指尖收攏段
      (list (list (* s 1206.0) -99.0  732.0)  32.0  18.0) ; 手掌末端圓頂
    )
  )
  (setq n-pts (length arm-pts))
  (setq arm-secs nil)
  (setq i 0)
  (while (< i n-pts)
    (setq p-curr (nth 0 (nth i arm-pts)))
    (setq ru     (nth 1 (nth i arm-pts)))
    (setq rv     (nth 2 (nth i arm-pts)))
    (cond
      ((= i 0)
       (setq p-next (nth 0 (nth (1+ i) arm-pts)))
       (setq tang (snx:v-unit (snx:v-sub p-next p-curr)))
      )
      ((= i (1- n-pts))
       (setq p-prev (nth 0 (nth (1- i) arm-pts)))
       (setq tang (snx:v-unit (snx:v-sub p-curr p-prev)))
      )
      (T
       (setq p-prev (nth 0 (nth (1- i) arm-pts)))
       (setq p-next (nth 0 (nth (1+ i) arm-pts)))
       (setq tang (snx:v-unit (snx:v-sub p-next p-prev)))
      )
    )
    (setq arm-secs (append arm-secs (list (list p-curr tang ref-u ru rv))))
    (setq i (1+ i))
  )
  (setq arm-solid (snx:loft-oriented-sections arm-secs "SNORLAX-BODY-TEAL"))

  ;; 建立手掌下緣 5 支白色彎曲圓錐手爪 (依 00210.jpg 側視圖與 00110.jpg 正視圖排列)
  (setq claw-offsets '(-96.0 -48.0 0.0 48.0 96.0))
  (setq idx 0)
  (foreach dy claw-offsets
    ;; 中央爪略長，兩側爪略短並沿手掌弧面分布
    (setq cx0 (* s (- 1185.0 (* 0.0022 dy dy))))
    (setq cy0 (+ -98.0 dy))
    (setq cz0 (+ 765.0 (* 0.0018 dy dy)))
    (setq claw-pts
      (list
        (list (list (* s (- (abs cx0) 12.0)) cy0 (+ cz0 25.0)) 18.0) ; 嵌入掌內基座
        (list (list cx0                       cy0 cz0)          16.5) ; 出掌面根部
        (list (list (* s (+ (abs cx0)  8.0)) cy0 (- cz0 24.0)) 12.0) ; 爪身中段
        (list (list (* s (+ (abs cx0) 11.0)) cy0 (- cz0 46.0))  6.2) ; 爪尖收束
        (list (list (* s (+ (abs cx0) 10.0)) cy0 (- cz0 60.0))  1.5) ; 銳利爪尖
      )
    )
    (snx:loft-tube-along-pts claw-pts '(0.0 1.0 0.0) "SNORLAX-CLAWS-WHITE")
    (setq idx (1+ idx))
  )
  arm-solid
)

;; 【模組 G】建立左右豐滿腳掌、底部肉球與 6 支大型彎曲腳爪
(defun snx:build-foot-and-claws (side / s ang ca sa foot-cx foot-cy u-dir v-dir
                                        local-slices sl y-loc z-loc rw rh pt foot-secs foot-solid
                                        pad-secs k ang-c r-dist claw-base claw-dir claw-pts)
  (setq s (float side)) ; -1.0 = 左腳, +1.0 = 右腳
  ;; 雙腳外八展開角 16 度 (0.27925 rad)
  (setq ang (* s -0.27925))
  (setq ca (cos ang))
  (setq sa (sin ang))
  (setq foot-cx (* s 565.0))
  (setq foot-cy -95.0)
  ;; 腳掌長軸方向 v-dir (由腳跟指向腳尖: -Y 偏外八) 與橫軸方向 u-dir
  (setq u-dir (list ca sa 0.0))
  (setq v-dir (list (- sa) ca 0.0))

  ;; 沿腳跟 (+310mm) 至腳尖 (-370mm) 配置 8 個垂直於腳掌長軸的橢圓斷面 (寬度半徑 rw, 高度半徑 rh)
  (setq local-slices
    '(
      ;; (y-local   z-center   rw     rh)
      ( 310.0        92.0     115.0   52.0) ; 腳跟後端圓弧
      ( 245.0       102.0     225.0   88.0) ; 腳跟飽滿段
      ( 135.0       112.0     295.0  110.0) ; 腳踝下方主體
      (   0.0       114.0     322.0  114.0) ; 腳掌中段最寬處
      (-135.0       106.0     318.0  105.0) ; 前腳掌寬闊區
      (-255.0        92.0     278.0   88.0) ; 腳趾根部前緣
      (-335.0        76.0     195.0   64.0) ; 腳尖收束段
      (-372.0        65.0      85.0   32.0) ; 腳尖前端圓頂
    )
  )
  (setq foot-secs nil)
  (foreach sl local-slices
    (setq y-loc (nth 0 sl))
    (setq z-loc (nth 1 sl))
    (setq rw    (nth 2 sl))
    (setq rh    (nth 3 sl))
    (setq pt
      (list
        (+ foot-cx (* y-loc (nth 0 v-dir)))
        (+ foot-cy (* y-loc (nth 1 v-dir)))
        z-loc
      )
    )
    (setq foot-secs (append foot-secs (list (list pt v-dir u-dir rw rh))))
  )
  (setq foot-solid (snx:loft-oriented-sections foot-secs "SNORLAX-FEET-CREAM"))

  ;; 建立腳底中央淺棕粉色橢圓肉球實體 (SNORLAX-PAWPAD-TAN, Z = -3.0 ~ +26.0 mm)
  (setq pad-secs
    (list
      (list (list foot-cx foot-cy  -3.0) '(0.0 0.0 1.0) u-dir 145.0 165.0)
      (list (list foot-cx foot-cy   4.0) '(0.0 0.0 1.0) u-dir 175.0 198.0)
      (list (list foot-cx foot-cy  26.0) '(0.0 0.0 1.0) u-dir 160.0 180.0)
    )
  )
  (snx:loft-oriented-sections pad-secs "SNORLAX-PAWPAD-TAN")

  ;; 建立每隻腳前緣 3 支大型微彎曲圓錐腳爪 (依 00110.jpg 與 00210.jpg 精確角度配置)
  (foreach k '(-1.0 0.0 1.0)
    ;; 三爪呈扇形分布於腳掌前緣 (局部角度偏移 k * 0.34 rad)
    (setq ang-c (+ ang (* k 0.34)))
    (setq claw-dir (list (sin ang-c) (- (cos ang-c)) 0.0))
    (setq claw-base
      (list
        (+ foot-cx (* 315.0 (nth 0 claw-dir)) (* k 22.0 ca))
        (+ foot-cy (* 315.0 (nth 1 claw-dir)) (* k 22.0 sa))
        72.0
      )
    )
    (setq claw-pts
      (list
        ;; 由腳掌內部向外、向下彎曲延伸成飽滿錐狀大爪
        (list (snx:v-add claw-base (snx:v-scale claw-dir -35.0))                          46.0)
        (list claw-base                                                                    42.0)
        (list (snx:v-add (snx:v-add claw-base (snx:v-scale claw-dir  48.0)) '(0.0 0.0 -10.0)) 31.0)
        (list (snx:v-add (snx:v-add claw-base (snx:v-scale claw-dir  92.0)) '(0.0 0.0 -24.0)) 16.5)
        (list (snx:v-add (snx:v-add claw-base (snx:v-scale claw-dir 122.0)) '(0.0 0.0 -36.0))  4.0)
      )
    )
    (snx:loft-tube-along-pts claw-pts '(0.0 0.0 1.0) "SNORLAX-CLAWS-WHITE")
  )
  foot-solid
)

;; 【模組 H】建立臉部立體五官 (微拱閉眼、微笑嘴線、兩側向上突起之三角錐下犬齒獠牙)
(defun snx:build-facial-features (/ s eye-pts mouth-pts fang-x fang-pts rim-pts)
  ;; 1. 左右微拱閉眼 (依 00110.jpg y=192..196, x=345..375 -> X = ±128..±282 mm, Z = 1886..1904 mm)
  ;;    精確貼合臉部 3D 椭圓曲面: Y(x,z) = cy_head - ry_head * sqrt(1 - (x/rx_head)^2) - 12mm
  (foreach s '(-1.0 1.0)
    (setq eye-pts
      (list
        (list (list (* s 128.0) -506.0 1888.0)  7.5)
        (list (list (* s 158.0) -498.0 1898.0) 11.5)
        (list (list (* s 195.0) -485.0 1904.0) 12.5)
        (list (list (* s 235.0) -468.0 1900.0) 12.0)
        (list (list (* s 265.0) -451.0 1891.0) 10.5)
        (list (list (* s 285.0) -438.0 1883.0)  7.0)
      )
    )
    (snx:loft-tube-along-pts eye-pts '(0.0 0.0 1.0) "SNORLAX-FACE-DARK")
  )

  ;; 2. 橫向嘴線 (依 00110.jpg y=222, x=372..428 -> X = -146..+146 mm, Z = 1742..1736 mm)
  (setq mouth-pts
    '(
      ((-148.0 -538.0 1744.0)  7.5)
      ((-105.0 -550.0 1740.0) 10.5)
      (( -52.0 -559.0 1737.0) 11.0)
      ((   0.0 -562.0 1736.0) 11.0)
      ((  52.0 -559.0 1737.0) 11.0)
      (( 105.0 -550.0 1740.0) 10.5)
      (( 148.0 -538.0 1744.0)  7.5)
    )
  )
  (snx:loft-tube-along-pts mouth-pts '(0.0 0.0 1.0) "SNORLAX-FACE-DARK")

  ;; 3. 嘴角左右兩顆向上突出的白色三角錐下犬齒 (獠牙) (X = ±112 mm, Z = 1740 -> 1792 mm)
  (foreach s '(-1.0 1.0)
    (setq fang-x (* s 112.0))
    ;; 白色獠牙錐體
    (setq fang-pts
      (list
        (list (list fang-x          -540.0 1738.0) 20.0)
        (list (list fang-x          -550.0 1748.0) 18.0)
        (list (list (* s 110.0)     -553.0 1766.0) 12.5)
        (list (list (* s 108.0)     -554.0 1782.0)  6.5)
        (list (list (* s 107.0)     -554.0 1794.0)  1.8)
      )
    )
    (snx:loft-tube-along-pts fang-pts '(0.0 1.0 0.0) "SNORLAX-CLAWS-WHITE")

    ;; 獠牙外緣深色立體輪廓環，重現 00110.jpg 中清晰的牙齒邊界線
    (setq rim-pts
      (list
        (list (list (* s 128.0) -544.0 1742.0) 5.5)
        (list (list (* s 118.0) -551.0 1772.0) 5.0)
        (list (list (* s 107.0) -554.0 1795.0) 4.5)
        (list (list (* s  97.0) -553.0 1772.0) 5.0)
        (list (list (* s  92.0) -548.0 1740.0) 5.5)
      )
    )
    (snx:loft-tube-along-pts rim-pts '(0.0 1.0 0.0) "SNORLAX-FACE-DARK")
  )
)

;; ----------------------------------------------------------------------------
;; 5. 主程式入口 (Main Command: SNORLAX3D)
;; ----------------------------------------------------------------------------

(defun c:SNORLAX3D (/ old-cmd old-osmode old-clayer old-delobj old-loftnorm old-isolines old-facetres
                      torso-solid head-solid ear-l ear-r arm-l arm-r main-body)
  (setq old-cmd      (getvar "CMDECHO"))
  (setq old-osmode   (getvar "OSMODE"))
  (setq old-clayer   (getvar "CLAYER"))
  (setq old-delobj   (getvar "DELOBJ"))
  (setq old-loftnorm (getvar "LOFTNORMALS"))
  (setq old-isolines (getvar "ISOLINES"))
  (setq old-facetres (getvar "FACETRES"))

  (setvar "CMDECHO" 0)
  (setvar "OSMODE"  0)
  (if old-delobj   (setvar "DELOBJ" 1))
  (if old-loftnorm (setvar "LOFTNORMALS" 1)) ; 1 = Smooth Fit 平滑 NURBS 混成
  (if old-isolines (setvar "ISOLINES" 24))
  (if old-facetres (setvar "FACETRES" 10.0)) ; 最高實體曲面平滑度

  (princ "\n============================================================")
  (princ "\n  正在建構 1:1 卡比獸 (Snorlax, H=2240mm) ACIS 3D 實體模型...")
  (princ "\n============================================================")

  ;; 確保在世界座標系 (WCS) 下執行
  (command "_UCS" "_W")

  ;; 1. 初始化圖層與 TrueColor 配色
  (snx:init-layers)

  ;; 2. 建立藍綠色軀幹與頭部 3DSOLID
  (princ "\n  [1/6] 正在混成軀幹與頭部 NURBS 3D 實體...")
  (setq torso-solid (snx:loft-horiz-sections (snx:get-torso-sections 0.0) "SNORLAX-BODY-TEAL"))
  (setq head-solid  (snx:loft-horiz-sections (snx:get-head-sections  0.0) "SNORLAX-BODY-TEAL"))

  ;; 3. 建立左右立體貓耳 3DSOLID (含前側耳窩內凹雕刻)
  (princ "\n  [2/6] 正在建立左右立體尖耳與耳窩細節...")
  (setq ear-l (snx:build-ear -1.0))
  (setq ear-r (snx:build-ear  1.0))

  ;; 4. 建立左右手臂與 10 支彎曲手爪 3DSOLID
  (princ "\n  [3/6] 正在混成 3D 空間弧線雙臂與手部十爪實體...")
  (setq arm-l (snx:build-arm-and-claws -1.0))
  (setq arm-r (snx:build-arm-and-claws  1.0))

  ;; 將同為深藍綠色的軀幹、頭部、雙耳與雙臂聯集 (_UNION) 為單一無縫主體 3DSOLID
  (setvar "CLAYER" "SNORLAX-BODY-TEAL")
  (setq main-body (snx:boolean-union (list torso-solid head-solid ear-l ear-r arm-l arm-r)))

  ;; 5. 以 CSG 布林交集與差集建立貼合式米白肚皮與 M 字額頭臉部實體
  (princ "\n  [4/6] 正在執行 3D 布林交集生成貼合肚皮與 M 字額頭臉部實體...")
  (snx:build-belly-patch)
  (snx:build-face-mask)

  ;; 6. 建立左右豐滿腳掌、底部肉球與 6 支大型彎曲腳爪
  (princ "\n  [5/6] 正在建立外八立體腳掌、腳底肉球與腳部六爪實體...")
  (snx:build-foot-and-claws -1.0)
  (snx:build-foot-and-claws  1.0)

  ;; 7. 建立立體瞇瞇眼、微笑嘴線與雙側向上犬齒獠牙
  (princ "\n  [6/6] 正在雕刻臉部微拱閉眼、嘴線與立體下犬齒獠牙...")
  (snx:build-facial-features)

  ;; 8. 切換至東南等角立體視角與「擬真 (Realistic) / 概念 (Conceptual)」視覺樣式並縮放至全圖
  (vl-catch-all-apply
    '(lambda ()
       (command "_-VPOINT" "1,-1.6,0.65")
       (command "_-VISUALSTYLES" "_Current" "_Conceptual")
       (command "_ZOOM" "_E")
     )
  )

  ;; 還原系統變數
  (if old-delobj   (setvar "DELOBJ" old-delobj))
  (if old-loftnorm (setvar "LOFTNORMALS" old-loftnorm))
  (setvar "CLAYER" old-clayer)
  (setvar "OSMODE" old-osmode)
  (setvar "CMDECHO" old-cmd)

  (princ "\n============================================================")
  (princ "\n  卡比獸 (Snorlax) 1:1 3D 實體模型 (3DSOLID) 建置完成！")
  (princ "\n  建議將視覺樣式切換為「概念 (Conceptual)」或「擬真 (Realistic)」檢視。")
  (princ "\n============================================================")
  (princ)
)

(princ "\n>>> 已成功載入 snorlax_3d_solid.lsp！請輸入 SNORLAX3D 執行卡比獸 3D 實體建模 <<<")
(princ)
