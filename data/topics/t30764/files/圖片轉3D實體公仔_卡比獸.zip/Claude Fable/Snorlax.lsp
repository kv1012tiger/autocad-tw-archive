;;; ==========================================================================
;;;  Snorlax.lsp  -  Snorlax 3D SOLID model for AutoCAD (pure AutoLISP)
;;;  Command : SNORLAX
;;;  Units   : mm, 1:1.  Total height 2240 mm (2.24 m), feet on Z = 0.
;;;  Axes    : +Z up, face looks toward -Y, +X = model's left hand side.
;;;  Output  : true 3DSOLID entities (ACIS), smooth lofted / revolved surfaces,
;;;            colour regions are boolean-split so nothing overlaps.
;;;  Layers  : SNORLAX-BODY (teal)  SNORLAX-CREAM (belly, face, feet)
;;;            SNORLAX-DARK (eyes, mouth)  SNORLAX-CLAW (claws, teeth)
;;;  Needs   : AutoCAD 2011 or newer (full version, not LT before 2024).
;;; ==========================================================================

;; ---------------------------------------------------------------- utilities
(defun sn:fin ( / n)
  (setq n 0)
  (while (and (= 1 (logand 1 (getvar "CMDACTIVE"))) (< n 4)) (command "") (setq n (1+ n)))
  (if (= 1 (logand 1 (getvar "CMDACTIVE"))) (command)))

(defun sn:sv (name val)
  (if (getvar name)
    (progn (setq sn:*vars* (cons (cons name (getvar name)) sn:*vars*))
           (setvar name val))))

(defun sn:restore ()
  (foreach p sn:*vars* (vl-catch-all-apply 'setvar (list (car p) (cdr p))))
  (setq sn:*vars* nil))

(defun sn:v+ (a b) (mapcar '+ a b))
(defun sn:v* (a k) (mapcar '(lambda (x) (* x k)) a))
(defun sn:unit (a / l) (setq l (distance '(0.0 0.0 0.0) a)) (sn:v* a (/ 1.0 l)))
(defun sn:deg (r) (* 180.0 (/ r pi)))

(defun sn:layer (name aci r g b)
  (if (not (tblsearch "LAYER" name))
    (entmake (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord")
                   '(100 . "AcDbLayerTableRecord") (cons 2 name) '(70 . 0)
                   (cons 62 aci) (cons 420 (+ (* r 65536) (* g 256) b))
                   '(6 . "Continuous")))))

(defun sn:setlay (e name / ed)
  (setq ed (entget e))
  (entmod (subst (cons 8 name) (assoc 8 ed) ed)))

(defun sn:alive (lst / r)
  (foreach e lst (if (and (not r) (entget e)) (setq r e)))
  r)

(defun sn:union (lst / ss)
  (if (cdr lst)
    (progn (setq ss (ssadd))
           (foreach e lst (ssadd e ss))
           (command "_.UNION" ss "")
           (sn:alive lst))
    (car lst)))

(defun sn:sub (a b) (command "_.SUBTRACT" a "" b "") a)

(defun sn:int (a b) (command "_.INTERSECT" a b "") (sn:alive (list a b)))

(defun sn:copy (e)
  (command "_.COPY" e "" '(0.0 0.0 0.0) '(0.0 0.0 0.0))
  (sn:fin)
  (entlast))

(defun sn:move (e v) (command "_.MOVE" e "" '(0.0 0.0 0.0) v) e)

(defun sn:rot (e p1 p2 ang) (command "_.ROTATE3D" e "" "_2" p1 p2 ang) e)

(defun sn:mirror (e)                       ; mirrored copy about the YZ plane
  (command "_.MIRROR3D" e "" "_YZ" '(0.0 0.0 0.0) "_N")
  (entlast))

;; turn the solid's local +Z axis to direction DIR, then move origin to POS
(defun sn:orient (e dir pos / ax ang)
  (setq dir (sn:unit dir)
        ax  (list (- (cadr dir)) (car dir) 0.0)
        ang (atan (distance '(0.0 0.0 0.0) ax) (caddr dir)))
  (if (> (distance '(0.0 0.0 0.0) ax) 1e-9)
    (sn:rot e '(0.0 0.0 0.0) ax (sn:deg ang))
    (if (< (caddr dir) 0.0) (sn:rot e '(0.0 0.0 0.0) '(1.0 0.0 0.0) 180.0)))
  (sn:move e pos))

(defun sn:pline (pts)                      ; closed LWPOLYLINE, pts = ((x y bulge) ...)
  (entmake
    (append (list '(0 . "LWPOLYLINE") '(100 . "AcDbEntity") '(100 . "AcDbPolyline")
                  (cons 90 (length pts)) '(70 . 1))
            (apply 'append
                   (mapcar '(lambda (p) (list (list 10 (car p) (cadr p))
                                              (cons 42 (caddr p))))
                           pts))))
  (entlast))

(defun sn:region (lst / ss)
  (setq ss (ssadd))
  (foreach e lst (ssadd e ss))
  (command "_.REGION" ss "")
  (entlast))

;; ------------------------------------------------------- solid primitives
;; spheroid: axis = Z, equatorial radius RE, polar semi-axis RP, centre at origin
(defun sn:spheroid (re rp / r1 r2 h)
  (command "_.ELLIPSE" "_C" '(0.0 0.0 0.0) (list re 0.0 0.0) rp)
  (setq r1 (sn:region (list (entlast))))
  (setq r2 (sn:region (list (sn:pline (list (list 0.0 (- (+ rp 10.0)) 0.0)
                                             (list (+ re 10.0) (- (+ rp 10.0)) 0.0)
                                             (list (+ re 10.0) (+ rp 10.0) 0.0)
                                             (list 0.0 (+ rp 10.0) 0.0))))))
  (setq h (sn:int r1 r2))
  (command "_.REVOLVE" h "" '(0.0 0.0 0.0) '(0.0 1.0 0.0) 360.0)
  (sn:rot (entlast) '(0.0 0.0 0.0) '(1.0 0.0 0.0) 90.0))

;; smooth body of revolution: PTS = ((radius height) ...) first/last radius = 0
;; both poles are rounded (tangent perpendicular to the axis); axis = +Z
;; (a closed spline symmetric about the axis is drawn, then cut in half - this
;;  avoids the SPLINE tangent prompts, which differ between AutoCAD versions)
(defun sn:rev (pts / mid r1 r2 rg lo hi)
  (setq mid (reverse (cdr (reverse (cdr pts))))
        lo  (- (cadr (car pts)) 500.0)
        hi  (+ (cadr (last pts)) 500.0))
  (command "_.SPLINE")
  (foreach p pts (command p))
  (foreach p (reverse mid) (command (list (- (car p)) (cadr p))))
  (command "_C")
  (sn:fin)
  (setq r1 (sn:region (list (entlast))))
  (setq r2 (sn:region (list (sn:pline (list (list 0.0 lo 0.0) (list 5000.0 lo 0.0)
                                             (list 5000.0 hi 0.0) (list 0.0 hi 0.0))))))
  (setq rg (sn:int r1 r2))
  (command "_.REVOLVE" rg "" '(0.0 0.0 0.0) '(0.0 1.0 0.0) 360.0)
  (sn:rot (entlast) '(0.0 0.0 0.0) '(1.0 0.0 0.0) 90.0))

;; closed profile drawn in XY (x = model X, y = model Z)  ->  prism that runs
;; from the plane Y = 0 to Y = -3000 (i.e. a "projector" onto the front)
(defun sn:prism (e)
  (command "_.EXTRUDE" e "" "_D" '(0.0 0.0 0.0) '(0.0 0.0 3000.0))
  (sn:rot (entlast) '(0.0 0.0 0.0) '(1.0 0.0 0.0) 90.0))

;; rounded slot between (x1 z1) and (x2 z2), thickness T, as a projector prism
(defun sn:slot (a b th / u n h)
  (setq u (sn:unit (list (- (car b) (car a)) (- (cadr b) (cadr a)) 0.0))
        n (list (- (cadr u)) (car u))
        h (* 0.5 th))
  (sn:prism
    (sn:pline (list (list (- (car a) (* h (car n))) (- (cadr a) (* h (cadr n))) 0.0)
                    (list (- (car b) (* h (car n))) (- (cadr b) (* h (cadr n))) 1.0)
                    (list (+ (car b) (* h (car n))) (+ (cadr b) (* h (cadr n))) 0.0)
                    (list (+ (car a) (* h (car n))) (+ (cadr a) (* h (cadr n))) 1.0)))))

;; ------------------------------------------------------------------ main
(defun c:SNORLAX ( / *error* secs lst e torso head skin skinfull belly facep wedge
                     cutter cream creamfull blue prs dark teeth ear earR earL
                     arm armR armL p0 d i claws c foot footR footL feet slab
                     fc ang cdir tm)
  (defun *error* (msg)
    (sn:fin)
    (command "_.UNDO" "_E")
    (sn:restore)
    (if (and msg (not (wcmatch (strcase msg) "*CANCEL*,*QUIT*,*BREAK*")))
      (princ (strcat "\nSNORLAX error: " msg)))
    (princ))

  (setq tm (getvar "MILLISECS") sn:*vars* nil)
  (sn:sv "CMDECHO" 0)
  (command "_.UNDO" "_BE")
  (command "_.UCS" "_W")
  (sn:sv "OSMODE" 0)       (sn:sv "3DOSMODE" 1)   (sn:sv "DELOBJ" 2)
  (sn:sv "PELLIPSE" 0)     (sn:sv "AUNITS" 0)     (sn:sv "ANGBASE" 0.0)
  (sn:sv "ANGDIR" 0)       (sn:sv "LOFTNORMALS" 1)(sn:sv "SPLMETHOD" 0)
  (sn:sv "COPYMODE" 1)     (sn:sv "SOLIDHIST" 0)  (sn:sv "PLINEWID" 0.0)
  (sn:sv "ELEVATION" 0.0)  (sn:sv "THICKNESS" 0.0)(sn:sv "CLAYER" "0")
  (sn:sv "SURFACEASSOCIATIVITY" 0) (sn:sv "SURFACEMODELINGMODE" 0)
  (if (getvar "FACETRES") (setvar "FACETRES" 8.0))
  (if (getvar "ISOLINES") (setvar "ISOLINES" 8))

  (sn:layer "SNORLAX-BODY"  134  22 118 148)
  (sn:layer "SNORLAX-CREAM"  51 242 238 220)
  (sn:layer "SNORLAX-DARK"  250  38  44  48)
  (sn:layer "SNORLAX-CLAW"  255 252 252 248)

  (princ "\nSNORLAX: building torso and head ...")
  ;; ---- torso: loft through horizontal ellipses  (z  half-width  half-depth  y-centre)
  (setq secs '((  40.0 380.0 330.0   0.0)
               ( 110.0 600.0 520.0 -10.0)
               ( 250.0 800.0 690.0 -25.0)
               ( 470.0 915.0 785.0 -40.0)
               ( 740.0 910.0 780.0 -40.0)
               (1000.0 840.0 715.0 -30.0)
               (1220.0 720.0 610.0 -15.0)
               (1400.0 590.0 500.0  -5.0)
               (1520.0 470.0 410.0   0.0)
               (1640.0 330.0 300.0   0.0))
        lst nil)
  (foreach s secs
    (command "_.ELLIPSE" "_C" (list 0.0 (cadddr s) (car s))
             (list (cadr s) (cadddr s) (car s)) (caddr s))
    (setq lst (cons (entlast) lst)))
  (setq lst (reverse lst))
  (command "_.LOFT")
  (foreach e lst (command e))
  (command "" "")
  (sn:fin)
  (setq torso (entlast))

  ;; ---- head: oblate spheroid
  (setq head (sn:move (sn:spheroid 495.0 430.0) '(0.0 -20.0 1630.0)))
  (setq skin (sn:union (list torso head)))
  (setq skinfull (sn:copy skin))            ; kept as a cutting tool, deleted at the end

  (princ "\nSNORLAX: splitting belly / face colour regions ...")
  ;; ---- belly projector (ellipse) + face projector (heart shape with widow's peak)
  (command "_.ELLIPSE" "_C" '(0.0 810.0 0.0) '(720.0 810.0 0.0) 550.0)
  (setq belly (sn:prism (entlast)))
  (command "_.SPLINE"
           '(0.0 1410.0) '(200.0 1422.0) '(350.0 1480.0) '(430.0 1590.0)
           '(438.0 1700.0) '(410.0 1810.0) '(335.0 1905.0) '(220.0 1962.0)
           '(100.0 1978.0) '(0.0 1980.0) '(-100.0 1978.0) '(-220.0 1962.0)
           '(-335.0 1905.0) '(-410.0 1810.0) '(-438.0 1700.0) '(-430.0 1590.0)
           '(-350.0 1480.0) '(-200.0 1422.0) "_C")
  (sn:fin)
  (setq facep (sn:prism (entlast)))
  (setq wedge (sn:prism (sn:pline '((0.0 1890.0 0.0) (230.0 2030.0 0.0) (-230.0 2030.0 0.0)))))
  (setq facep  (sn:sub facep wedge))
  (setq cutter (sn:union (list belly facep)))
  (setq cream  (sn:int (sn:copy skin) (sn:copy cutter)))
  (setq blue   (sn:sub skin cutter))
  (setq creamfull (sn:copy cream))          ; cutting tool, consumed later

  (princ "\nSNORLAX: face details ...")
  ;; ---- eyes + mouth (inlaid dark solids)
  (setq prs (list (sn:slot '(  95.0 1868.0) '( 310.0 1892.0) 22.0)
                  (sn:slot '( -95.0 1868.0) '(-310.0 1892.0) 22.0)
                  (sn:slot '(-150.0 1782.0) '( 150.0 1782.0) 16.0)))
  (setq dark  (sn:int (sn:copy cream) (sn:union prs)))
  (setq cream (sn:sub cream (sn:copy dark)))
  ;; ---- two fangs (inlaid white solids)
  (setq prs (list (sn:prism (sn:pline '(( 76.0 1790.0 0.0) ( 124.0 1790.0 0.0) ( 100.0 1848.0 0.0))))
                  (sn:prism (sn:pline '((-124.0 1790.0 0.0) (-76.0 1790.0 0.0) (-100.0 1848.0 0.0))))))
  (setq teeth (sn:int (sn:copy cream) (sn:union prs)))
  (setq cream (sn:sub cream (sn:copy teeth)))

  (princ "\nSNORLAX: ears and arms ...")
  ;; ---- ears (rounded cones); tip reaches Z = 2240
  (setq ear  (sn:rev '((0.0 -50.0) (140.0 0.0) (128.0 110.0) (82.0 230.0)
                       (30.0 330.0) (0.0 356.4)))
        earR (sn:orient ear '(0.30 0.0 0.954) '(315.0 -10.0 1900.0))
        earL (sn:mirror earR))
  ;; ---- arms (teardrop bodies of revolution)
  (setq p0   '(560.0 0.0 1136.0)
        d    (sn:unit '(0.905 -0.05 -0.42))
        arm  (sn:rev '((0.0 -60.0) (250.0 0.0) (370.0 150.0) (375.0 290.0)
                       (310.0 420.0) (225.0 530.0) (140.0 640.0) (80.0 710.0)
                       (0.0 745.0)))
        armR (sn:orient arm d p0)
        armL (sn:mirror armR))
  (setq blue (sn:union (list blue earR earL armR armL)))
  (setq blue (sn:sub blue creamfull))

  (princ "\nSNORLAX: feet and claws ...")
  ;; ---- feet (flattened spheroids, cut by the ground and by the body)
  (setq fc    '(590.0 -60.0 50.0)
        footR (sn:move (sn:spheroid 345.0 160.0) fc)
        footL (sn:mirror footR)
        feet  (sn:union (list footR footL)))
  (command "_.BOX" '(-3000.0 -3000.0 -600.0) '(3000.0 3000.0 0.0))
  (setq slab (entlast))
  (setq feet (sn:sub feet slab))
  (setq feet (sn:sub feet skinfull))        ; skinfull is consumed here

  ;; ---- claws: 5 per hand, 3 per foot
  (setq claws nil i -2)
  (while (<= i 2)
    (command "_.CONE" '(0.0 0.0 0.0) 27.0 115.0)
    (setq c (sn:orient (entlast)
                       (sn:v+ d (list 0.0 (* i 0.20) -0.55))
                       (sn:v+ (sn:v+ p0 (sn:v* d 690.0)) (list 0.0 (* i 45.0) -40.0))))
    (setq claws (cons (sn:mirror c) (cons c claws)))
    (setq i (1+ i)))
  (foreach ang '(30.0 52.0 74.0)
    (setq cdir (list (sin (* pi (/ ang 180.0))) (- (cos (* pi (/ ang 180.0)))) 0.0))
    (command "_.CONE" '(0.0 0.0 0.0) 42.0 135.0)
    (setq c (sn:orient (entlast)
                       (sn:v+ cdir '(0.0 0.0 -0.12))
                       (sn:v+ (list (car fc) (cadr fc) 45.0) (sn:v* cdir 295.0))))
    (setq claws (cons (sn:mirror c) (cons c claws))))
  (setq claws (sn:union claws))
  (setq claws (sn:sub claws (sn:copy blue)))
  (setq claws (sn:sub claws (sn:copy feet)))

  ;; ---- layers / colours
  (sn:setlay blue  "SNORLAX-BODY")
  (sn:setlay cream "SNORLAX-CREAM")
  (sn:setlay feet  "SNORLAX-CREAM")
  (sn:setlay dark  "SNORLAX-DARK")
  (sn:setlay teeth "SNORLAX-CLAW")
  (sn:setlay claws "SNORLAX-CLAW")

  (command "_.UNDO" "_E")
  (sn:restore)
  ;; ---- display (ignored silently where no graphics window exists)
  (vl-catch-all-apply
    '(lambda ()
       (command "_.VPOINT" '(-0.9 -2.0 0.55))
       (command "_.ZOOM" "_E")
       (command "_.VSCURRENT" "_R")))
  (sn:fin)
  (princ (strcat "\nSNORLAX done: 6 solids, height 2240 mm, "
                 (rtos (/ (- (getvar "MILLISECS") tm) 1000.0) 2 1) " s."))
  (princ))

(princ "\nSnorlax.lsp loaded - type SNORLAX to build the 3D solid model.")
(princ)
