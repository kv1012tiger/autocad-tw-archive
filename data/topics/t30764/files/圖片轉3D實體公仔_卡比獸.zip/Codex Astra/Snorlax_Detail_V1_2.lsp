; SNORLAX_DETAIL_V1_2 - reference reconstruction, millimetres.
; Windows full AutoCAD 2021+; no external files or packages.
; Canonical height 224. Front = WCS -Y; up = WCS +Z.
; Closed analytic ellipse sections -> smooth ACIS 3DSOLID lofts.
; Colour parts overlap intentionally. Not a watertight print assembly.
(vl-load-com)
(defun sn:fail (msg) (princ (strcat "\n" msg)) (exit))

(defun sn:layer (name rgb /)
  (if (not (tblsearch "LAYER" name))
    (entmake (list '(0 . "LAYER") '(100 . "AcDbSymbolTableRecord")
      '(100 . "AcDbLayerTableRecord") (cons 2 name) '(70 . 0)
      '(62 . 7) (cons 420 rgb) '(6 . "Continuous"))))
  name)

(defun sn:track (e) (setq sn:made (cons e sn:made)) e)
(defun sn:del (e) (if (and e (entget e)) (entdel e)))
(defun sn:paint (e lay / d)
  (setq d (entget e))
  (entmod (append (vl-remove-if '(lambda (p) (member (car p) '(8 62 420))) d)
    (list (cons 8 lay) '(62 . 256)))) e)

; V1.1: force real division; integer division made the first ratio zero.
; All profiles use the same seam direction; rx >= ry avoids seam flips.
(defun sn:ring (row / x y z a b)
  (setq x (nth 0 row) y (nth 1 row) z (nth 2 row)
        a (nth 3 row) b (nth 4 row))
  (sn:track (entmakex (list '(0 . "ELLIPSE") '(100 . "AcDbEntity")
    '(8 . "0") '(100 . "AcDbEllipse") (cons 10 (list x y z))
    (cons 11 (list a 0.0 0.0)) '(210 0.0 0.0 1.0)
    (cons 40 (/ (float b) (float a))) '(41 . 0.0) (cons 42 (* 2.0 pi))))))

(defun sn:loft (rows lay / profiles ss e before row p)
  (setq ss (ssadd) profiles nil)
  (foreach row rows
    (setq e (sn:ring row))
    (if (not e) (sn:fail "Cannot create a loft section."))
    (setq profiles (cons e profiles)) (ssadd e ss))
  (setq before (entlast))
  (command-s "_.LOFT" "_MOde" "_SOlid" ss "" "_Cross")
  (setq e (entlast))
  (if (or (eq e before) (/= (cdr (assoc 0 (entget e))) "3DSOLID"))
    (sn:fail "LOFT did not return a 3DSOLID. Operation stopped."))
  (sn:track e)
  (foreach p profiles (sn:del p))
  (sn:paint e lay)
  (setq sn:solids (cons e sn:solids)) e)

(defun sn:union (a b / r)
  (setq r (vl-catch-all-apply 'vla-Boolean
    (list (vlax-ename->vla-object a) 0 (vlax-ename->vla-object b))))
  (if (vl-catch-all-error-p r)
    (sn:fail (strcat "Solid union failed: " (vl-catch-all-error-message r)))) a)

; Ellipsoid from 19 analytic sections, not a faceted sphere mesh.
; Canonical radii a>=b; optional rigid rotation creates the final orientation.
(defun sn:oval (ctr a b h lay / rows i sn:theta f)
  (setq rows nil i 0)
  (repeat 19
    (setq sn:theta (+ (- (/ pi 2.0)) (* pi (/ i 18.0)))
          f (max 0.002 (cos sn:theta)))
    (setq rows (cons (list (car ctr) (cadr ctr)
      (+ (caddr ctr) (* h (sin sn:theta))) (* a f) (* b f)) rows))
    (setq i (1+ i)))
  (sn:loft (reverse rows) lay))

(defun sn:mirrorrows (rows sign)
  (mapcar '(lambda (r) (cons (* sign (car r)) (cdr r))) rows))

; Cut the central forehead notch into the cream face, exposing blue behind.
(defun sn:notch (face / pl regs reg cut r)
  (setq pl (sn:track (entmakex (list '(0 . "LWPOLYLINE")
    '(100 . "AcDbEntity") '(100 . "AcDbPolyline") '(90 . 5) '(70 . 1)
    '(10 -22.0 208.0) '(10 0.0 196.0) '(10 22.0 208.0)
    '(10 22.0 230.0) '(10 -22.0 230.0)))))
  (setq regs (vlax-make-safearray vlax-vbObject '(0 . 0)))
  (vlax-safearray-put-element regs 0 (vlax-ename->vla-object pl))
  (setq reg (car (vlax-safearray->list (vlax-variant-value
    (vla-AddRegion sn:space regs)))))
  (sn:track (vlax-vla-object->ename reg))
  (setq cut (vla-AddExtrudedSolid sn:space reg 140.0 0.0))
  (sn:track (vlax-vla-object->ename cut))
  (vla-Rotate3D cut (vlax-3d-point '(0 0 0)) (vlax-3d-point '(1 0 0)) (/ pi 2.0))
  (vla-Move cut (vlax-3d-point '(0 0 0)) (vlax-3d-point '(0 70 0)))
  (setq r (vl-catch-all-apply 'vla-Boolean
    (list (vlax-ename->vla-object face) 2 cut)))
  (if (vl-catch-all-error-p r) (sn:fail "Face notch subtraction failed."))
  (vla-Delete reg) (sn:del pl))

(defun sn:restore (/ p)
  (foreach p sn:vars (setvar (car p) (cdr p)))
  (if sn:undo (progn (vla-EndUndoMark sn:doc) (setq sn:undo nil))))

(defun c:SNORLAX (/ *error* sn:made sn:solids sn:vars sn:doc sn:space sn:undo
  ht base fac body head face arm ear foot e sign x y z k rows obj count)
  (defun *error* (msg)
    (foreach e sn:made (sn:del e))
    (sn:restore)
    (if msg (princ (strcat "\nSNORLAX stopped: " msg))) (princ))
  (if (= 1 (getvar "CVPORT"))
    (princ "\nSwitch to Model space before running SNORLAX.")
    (progn
      (initget 6) (setq ht (getreal "\nOverall height in mm <224>: "))
      (if (not ht) (setq ht 224.0))
      (setq base (getpoint "\nFoot-level insertion point <0,0,0>: "))
      (if base (setq base (trans base 1 0)) (setq base '(0.0 0.0 0.0)))
      (setq fac (/ ht 224.0)
        sn:doc (vla-get-ActiveDocument (vlax-get-acad-object))
        sn:space (vla-get-ModelSpace sn:doc)
        sn:vars (mapcar '(lambda (v) (cons v (getvar v)))
          '("CMDECHO" "OSMODE" "DELOBJ" "LOFTNORMALS" "LOFTPARAM" "CECOLOR")))
      (vla-StartUndoMark sn:doc) (setq sn:undo T)
      (setvar "CMDECHO" 0) (setvar "OSMODE" 0) (setvar "DELOBJ" 0)
      (setvar "LOFTNORMALS" 1) (setvar "LOFTPARAM" 7) (setvar "CECOLOR" "BYLAYER")
      (sn:layer "SN1-TEAL" 556950)
      (sn:layer "SN1-CREAM" 16118232)
      (sn:layer "SN1-IVORY" 16776431)
      (sn:layer "SN1-FACE" 2303017)
      (princ "\nBuilding smooth body and head...")
      (setq body (sn:loft '(
        (0 7 15 38 26) (0 7 18 63 37) (0 7 25 79 45)
        (0 7 38 87 52) (0 7 55 90 58) (0 7 76 88 61)
        (0 6 97 81 57) (0 5 116 71 50) (0 4 132 59 42)
        (0 3 144 46 34) (0 3 151 30 24) (0 3 155 10 9)) "SN1-TEAL"))
      (setq head (sn:loft '(
        (0 0 132 26 23) (0 0 141 39 32) (0 0 153 46 37)
        (0 0 169 50 40) (0 0 183 49 39) (0 0 196 44 35)
        (0 0 205 34 27) (0 0 211 19 16) (0 0 213 1 0.8)) "SN1-TEAL"))
      (sn:union body head)
      (foreach sign '(-1 1)
        (setq ear (sn:loft (sn:mirrorrows '(
          (34 1 193 15 12) (37 1 202 12 9)
          (41 1 213 7 5) (43 1 221 3 2.3) (43 1 224 0.35 0.25)) sign) "SN1-TEAL"))
        (sn:union body ear)
        (setq arm (sn:loft (sn:mirrorrows '(
          (112 -4 78 2 1.8) (113 -4 82 8 7) (109 -3 92 13 11)
          (101 -1 105 17 14) (90 1 119 19 16)
          (76 3 132 18 15) (64 4 140 12 11) (59 4 142 3 2.5)) sign) "SN1-TEAL"))
        (sn:union body arm))
      (princ "\nBuilding belly, notched face and feet...")
      (sn:loft '(
        (0 -33 27 2 1) (0 -33 30 25 8) (0 -33 37 47 15)
        (0 -33 49 61 22) (0 -33 65 68 26) (0 -32 83 68 28)
        (0 -30 101 61 27) (0 -27 117 51 25) (0 -24 131 40 21)
        (0 -22 141 29 16) (0 -21 147 14 10) (0 -21 149 1 0.7)) "SN1-CREAM")
      (setq face (sn:loft '(
        (0 -25 138 2 1) (0 -27 142 23 12) (0 -28 150 35 19)
        (0 -29 162 41 22) (0 -29 175 43 23)
        (0 -28 186 40 22) (0 -26 196 32 19)
        (0 -23 203 21 14) (0 -22 206 7 5) (0 -22 207 0.5 0.4)) "SN1-CREAM"))
      (sn:notch face)
      (foreach sign '(-1 1)
        (setq foot (sn:loft (sn:mirrorrows '(
          (55 -10 0 17 16) (55 -10 2 25 23) (55 -10 6 29 26)
          (55 -9 12 29 26) (55 -8 18 23 21) (55 -7 22 12 11)
          (55 -7 23 1 0.8)) sign) "SN1-CREAM"))
        ; Three separate gently curved toe claws per foot.
        (foreach k '(-1 0 1)
          (setq x (* sign (+ 55 (* k 17))) y (+ -34 (* (abs k) 3)))
          (sn:loft (list (list x (- y 7) 1 0.25 0.22)
            (list x (- y 5) 3 2.7 2.3) (list x (- y 2) 6 4.4 3.8)
            (list x y 9 4.8 4.1) (list x (+ y 2) 12 2.8 2.5)) "SN1-IVORY"))
        ; Four small hand claws, visible from both front and side.
        (foreach k '(-1.5 -0.5 0.5 1.5)
          (setq x (* sign (+ 112 (* k 3.3))) y (+ -6 (* k 2)))
          (sn:loft (list (list (+ x (* sign 1.2)) (- y 2) 74 0.18 0.15)
            (list x (- y 1) 77 1.5 1.3) (list x y 81 2.3 2)
            (list x (+ y 1) 84 1.5 1.3)) "SN1-IVORY")))
      (princ "\nBuilding closed eyes, smile and two teeth...")
      ; Narrow curved eyelids: solid ribbons lofted along X after rotation.
      (foreach sign '(-1 1)
        (setq e (sn:loft '(
          (0 0 -10 0.12 0.1) (-0.9 0 -7 0.6 0.5)
          (-1.4 0 -3 0.8 0.7) (-1.4 0 2 0.8 0.7)
          (-0.8 0 7 0.5 0.4) (0 0 10 0.12 0.1)) "SN1-FACE"))
        (setq obj (vlax-ename->vla-object e))
        (vla-Rotate3D obj (vlax-3d-point '(0 0 0)) (vlax-3d-point '(0 1 0)) (/ pi 2))
        (vla-Move obj (vlax-3d-point '(0 0 0)) (vlax-3d-point (list (* sign 20) -47.7 187)))
        (sn:loft (list (list (* sign 11) -51.4 173.8 2.8 1.8)
          (list (* sign 11) -51.7 176 2.0 1.5)
          (list (* sign 10.8) -51.6 179.2 0.15 0.12)) "SN1-IVORY"))
      (setq e (sn:oval '(0 0 0) 0.85 0.65 14 "SN1-FACE")
            obj (vlax-ename->vla-object e))
      (vla-Rotate3D obj (vlax-3d-point '(0 0 0)) (vlax-3d-point '(0 1 0)) (/ pi 2))
      (vla-Move obj (vlax-3d-point '(0 0 0)) (vlax-3d-point '(0 -52.0 173.6)))
      (setq count 0)
      (foreach e sn:solids
        (if (entget e)
          (progn (setq obj (vlax-ename->vla-object e))
            (vla-ScaleEntity obj (vlax-3d-point '(0 0 0)) fac)
            (vla-Move obj (vlax-3d-point '(0 0 0)) (vlax-3d-point base))
            (setq count (1+ count)))))
      (sn:restore)
      (vla-Regen sn:doc 1)
      (princ (strcat "\nSNORLAX complete: " (itoa count) " 3DSOLIDs. Height "
        (rtos ht 2 1) " mm. Front faces WCS -Y."))
      (princ "\nUse Front / SE Isometric and a shaded visual style. One UNDO removes this build.")))
  (princ))
(princ "\nSNORLAX_DETAIL_V1_2 loaded. Run SNORLAX to build the model.")
(princ)
