;(C) 2009 XANADU - www.xanadu.cz
;select all blocks like selected block(s)

(defun C:SELBLK ( / e ss)
 (setq e (entsel "Select a block name to select: "))
 (if e (setq ss (ssget "_X" (list(cons 2 (cdr (assoc 2 (entget (car e)))))(cons 0 "INSERT")))))
 (if (zerop (getvar "CMDACTIVE"))
  (progn (sssetfirst ss ss)(princ "Use 'P' for this selection set: ")(princ))
   ss
 )
)

(defun C:SELBLKS ( / e blk ss blkl)
 (setq blkl ""  ss (ssadd))
 (while (setq e (entsel "\nSelect a block name to select <exit>: "))
  (setq blkl (strcat blkl "," (cdr (assoc 2 (entget (car e))))))
  (princ (substr blkl 2))
 );while
 (setq blkl (substr blkl 2))
 (if (> blkl "") (setq ss (ssget "_X" (list (cons 2 blkl)(cons 0 "INSERT")))))
 (if (zerop (getvar "CMDACTIVE"))
  (progn (sssetfirst ss ss)(princ "Use 'P' for this selection set: ")(princ))
   ss
 )
)

(princ "\nXanadu SELBLK + SELBLKS commands loaded.")(princ)
